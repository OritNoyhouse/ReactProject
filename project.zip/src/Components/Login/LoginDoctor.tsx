export default class LoginDoctor {
    constructor
        (public doctorId: number,          
            public password: string) 
            { }
}