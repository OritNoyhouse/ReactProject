
import { TextField } from "@material-ui/core";
import * as React from 'react';
import { Button, makeStyles, OutlinedInput, Typography, Theme } from '@material-ui/core';
import SendIcon from '@mui/icons-material/Send';
// import { palette } from '@mui/system';
import AbcSharpIcon from '@mui/icons-material/AbcSharp';
import { ClassNames } from '@emotion/react';
import DeleteIcon from '@mui/icons-material/Delete';
import Stack from '@mui/material/Stack';
import { blue } from '@material-ui/core/colors';
import { Opacity } from '@material-ui/icons';

import { clear } from 'console';
import axios from "axios";
import { useForm } from "react-hook-form";
import ManagerClass from "../Manager/ManagerClass";
import { Link } from "react-router-dom";
// import './ShortestRoute.css';



function RouteS(): JSX.Element {
    return (
       
<div>
               <h1>המסלול המהיר למשמרת הקרובה</h1>
               <iframe src="https://www.google.com/maps/embed?pb=!1m38!1m12!1m3!1d13522.015618895737!2d34.837918578630074!3d32.08266417980705!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m23!3e0!4m3!3m2!1d32.0760824!2d34.8331874!4m5!1s0x151d4a2f46c831f3%3A0x9d036eb76b29d834!2z15fXmdeZ150g16TXqNecLCDXkdeg15kg15HXqNen!3m2!1d32.0907604!2d34.8282811!4m5!1s0x151d4a37f9012361%3A0x4a80e1077f1cdac!2z15HXkNeo15kgMTcsINeR16DXmSDXkdeo16c!3m2!1d32.076540099999995!2d34.8291107!4m5!1s0x151d4a24c0f8b095%3A0x42c32163f4111613!2z15HXoNeZINeR16jXpywg16jXkdeZINei16fXmdeR15AsINeR16DXmSDXkdeo16c!3m2!1d32.0858316!2d34.8332924!5e0!3m2!1siw!2sil!4v1645631544742!5m2!1siw!2sil" width="600" height="450" loading="lazy"></iframe>
          
</div>

);
}

export default RouteS;