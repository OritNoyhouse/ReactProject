export default class User {
    constructor(public Id: number,
        public FirstName: string,
        public LastName: string,
        public Statuscovid19: string,
        public Gender: string,
         public CodeAdress: number,
         public Machine: number,
         public  MedicalCondition: number,       
        public Age: number,
        public  LevelUrgent: number, 
        public  DoctorId: number, 
        public  LocationId: number, 
        public Password: string,
        public PhoneNumber: string) { } 
}