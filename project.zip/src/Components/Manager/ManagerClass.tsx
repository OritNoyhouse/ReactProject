export default class ManagerClass {
    constructor(public password: string,
        
      ) { }
}