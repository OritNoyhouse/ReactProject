import { TextField } from "@material-ui/core";
import './Manager.css';
import * as React from 'react';
import { Button, makeStyles, OutlinedInput, Typography, Theme } from '@material-ui/core';
import SendIcon from '@mui/icons-material/Send';
// import { palette } from '@mui/system';
import AbcSharpIcon from '@mui/icons-material/AbcSharp';
import { ClassNames } from '@emotion/react';
import DeleteIcon from '@mui/icons-material/Delete';
import Stack from '@mui/material/Stack';
import { blue } from '@material-ui/core/colors';
import { Opacity } from '@material-ui/icons';

import { clear } from 'console';
import LoginDoctor from '../Login/LoginDoctor';
import axios from "axios";
import { useForm } from "react-hook-form";
import ManagerClass from "../Manager/ManagerClass";
import { Link } from "react-router-dom";




function Manager(): JSX.Element {

    const useStyles = makeStyles(textField => ({
        root: {
            marginTop: "12px",
            marginBottom: "7px"
        },

    }));
    const classes = useStyles();

    const { register, handleSubmit, formState: { errors } } = useForm<ManagerClass>();
    return (
        <div className="header">

<br>
                </br>
            <div className="header">כניסת מנהל</div>
            <form>
                
                <p>
                    <TextField id='idDoctor' className={classes.root} label="סיסמא" type="password"
                        {...register('password', { required: true, minLength: 2 })}
                    />
                    {errors.password?.type === "required" && <span className='error' > <br />Required field</span>}
                    {errors.password?.type === "minLength" && <span className='error'><br />too short</span>}
                </p>
                
              
                <Link to="/area">
                    <Button id="button" variant="contained" type='submit'
                        color="primary"//***********איך גורמים שבלחיצה על שליחה, יעורר את הפעולה שנמצאת בפרוגרס */
                       >
                      אישור
                    </Button>
                </Link>

            </form>
           
        </div>

    );
}

export default Manager;
