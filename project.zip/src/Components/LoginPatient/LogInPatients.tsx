export default class LogInPatients {
    constructor
        (public patientId: number,          
            public password: string) 
            { }
}