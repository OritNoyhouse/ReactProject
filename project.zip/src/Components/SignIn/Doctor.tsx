export default class Doctor {
    constructor(public UserId: number,
        public DoctorfName: string,
        public DoctorlName: string,
        public DoctorStatusCovid19: string,
        public DoctorlGender: string,
        public DoctorPassword: string,
        public DoctorStreet: string,
        public DoctorNumberOfBuilding: number,
        public DoctorCity: string,
        public DoctorPhoneNumber: string) { }
}