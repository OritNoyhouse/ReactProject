import * as React from 'react';
import { Button, makeStyles, OutlinedInput, Typography, Theme } from '@material-ui/core';
import { TextField } from '@material-ui/core';
import SendIcon from '@mui/icons-material/Send';
// import { palette } from '@mui/system';
import AbcSharpIcon from '@mui/icons-material/AbcSharp';
import { ClassNames } from '@emotion/react';
import DeleteIcon from '@mui/icons-material/Delete';
import Stack from '@mui/material/Stack';
import { blue } from '@material-ui/core/colors';
import { Opacity } from '@material-ui/icons';

import { clear } from 'console';
import Doctor from '../SignIn/Doctor';
import axios from "axios";
import { useForm } from "react-hook-form";
import "./SignIn.css"

import { Link } from "react-router-dom";



const useStyles = makeStyles(textField => ({
    root: {
        marginTop: "12px",
        marginBottom: "7px"
    },
    buttonCancel: {
        //  color: blue[600],
    },
    buttonSend: {
        //   color: blue[900]
    },
}));

//const classes = useStyles();

function SignIn(): JSX.Element {
    const url = "https://localhost:44346/";
    const { register, handleSubmit, formState: { errors } } = useForm<Doctor>();
    const addAdmin = async (data: Doctor) => {
        console.log(data); 
        let adminPromise = axios.post(url + "api/Doctor", data);
        let response = await adminPromise;
        console.log(response.data);
    }
    const classes = useStyles();

    const handleCancel = () => {
        //*********************איך מוחקים את התוכן של הפקדים***********************//
    };
    return <div className='header'>
       
        <div className='header'>רישום רופא חדש</div>
        <form onSubmit={handleSubmit(addAdmin)} className='LogIn'>
        
        <p>
                <TextField id='UserId' className={classes.root} label="תעודת זהות" type="text"{...register('UserId', { required: true, minLength: 2 })} />
                {errors.UserId?.type === "required" && <span className='error' > <br />Required field</span>}
                {errors.UserId?.type === "minLength" && <span className='error'><br />too short</span>}
            </p>
            <p>
                <TextField id='FName' className={classes.root} label="שם פרטי" type="text"{...register('DoctorfName', { required: true })} />
                {errors.DoctorfName?.type === "required" && <span className='error' > <br />Required field</span>}
   
            </p>

            <p>
                <TextField id='LName' className={classes.root} label="שם משפחה" type="text"{...register('DoctorlName', { required: true })} />
                {errors.DoctorfName?.type === "required" && <span className='error' > <br />Required field</span>}
               
            </p>
            <p>
                <TextField id="DoctorPhoneNumber" className={classes.root} label="מספר פלאפון" type="text"{...register('DoctorPhoneNumber', { required: true })} />
                {errors.DoctorPhoneNumber?.type === "required" && <span className='error' > <br />Required field</span>}
               
            </p>
            <p>
                <TextField id="Password" className={classes.root} label="סיסמא" type="password"{...register('DoctorPassword', { required: true })} />
                {errors.DoctorPassword?.type === "required" && <span className='error' > <br />Required field</span>}
               
            </p>
            <p>
                <TextField id="DoctorStatusCovid19" className={classes.root} label="סטטוס קורונה" type="text"{...register('DoctorStatusCovid19', { required: true})} />
                {errors.DoctorStatusCovid19?.type === "required" && <span className='error' > <br />Required field</span>}
                
            </p>
            <p>
                <TextField id="DoctorlGender" className={classes.root} label="מגדר" type="text"{...register('DoctorlGender', { required: true })} />
                {errors.DoctorlGender?.type === "required" && <span className='error' > <br />Required field</span>}
               
            </p>
           
            
            <p>
                <TextField id="DoctorStreet" className={classes.root} label="רחוב" type="text"{...register('DoctorStreet', { required: true })} />
                {errors.DoctorStreet?.type === "required" && <span className='error' > <br />Required field</span>}
               
            </p>
            <p>
                <TextField id="DoctorNumberOfBuilding" className={classes.root} label="מספר בית" type="number"{...register('DoctorNumberOfBuilding', { required: true })} />
                {errors.DoctorNumberOfBuilding?.type === "required" && <span className='error' > <br />Required field</span>}
               
            </p>
            <p>
                <TextField id="DoctorCity" className={classes.root} label="עיר" type="text"{...register('DoctorCity', { required: true })} />
                {errors.DoctorCity?.type === "required" && <span className='error' > <br />Required field</span>}
              
            </p>
            

            {/* <Button variant="outlined">
            existing school
            </Button>

            <Button variant="outlined" >
                new school
            </Button>
            <br></br> */}

            {/* <Button variant="outlined" className={classes.buttonCancel}
                color="primary"
                startIcon={<DeleteIcon />} onClick={handleCancel} >
                Cancel
            </Button> */}
            {/* <Link to="/newSchool"> */}


            
           
                <Button id="button" variant="contained" className={classes.buttonSend} type='submit'
                    color="primary"//***********איך גורמים שבלחיצה על שליחה, יעורר את הפעולה שנמצאת בפרוגרס */
                   >
                   הרשמה
                </Button>

            {/* </Link> */}
        </form>
    </div>
}
export default SignIn;
