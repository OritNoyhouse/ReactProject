export default class Adress {
    constructor(public UserId: number,
        public AdressStreet: string,
        public AdressNumber: number,
        public AdressCity: string,
        public AdressFloor: number,
        public AdressCnisa: string,
        public AdressNumberFlat: number,
        public AdressParking: boolean,
        public Eeara: string,) { }
}