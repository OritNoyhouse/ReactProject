


import { getDefaultNormalizer } from '@testing-library/react';
import LogInPatients from './Components/LoginPatient/LoginPatient';

import AreaOfPatient from './Components/LoginPatient/AreaOfPatient';
import React, { Component } from 'react';
import './App.css';
// import logo from './logo.svg';
import './App.css';
// import Progress from "./Components/Progress";
import ReactDOM from 'react-dom';
  import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
 import Nav from './Components/Nav/Nav';
 import Foot from './Components/Foot/Foot';
 import Manager from './Components/Manager/Manager';
 import Area from './Components/Manager/Area';
 import Home  from './Components/Home/Home';
 import SignInClient  from './Components/SignInClient/SignInClient';
 
import Information from './Components/Information/Information';
// import Nav from './Components/Nav/Nav';
 import LogIn from './Components/Login/Login';
 import ListOfClients from './Components/ListOfClients/ListOfClients';
 
 import AreaOfDoctor from './Components/Login/AreaOfDoctor';
 
 import SignIn from './Components/SignIn/SignIn';
 import RouteS from './Components/Route/RouteS';
// import NewSchool from './Components/NewSchool/NewSchool';
// import ChooseProps from './Components/ChooseProps/ChooseProps';
// import AddProp from './Components/AddProp/AddProp';
// import SignIn from './Components/SignIn/SignIn';
// import {
//   BrowserRouter, Route, Routes,Switch
// }
// from "react-router-dom";
function App() {
  return (
    <div className="App">
     
      <Router>
     <Nav></Nav>
     
       
      <Routes>
        <Route path="/addDoctor" element={<SignIn />} />
        <Route path="/" element={<Home />} />
        <Route path="/logindoctor" element={<LogIn/>} />
        <Route path="/manager" element={<Manager/>} />
        <Route path="/area" element={<Area/>} />
        <Route path="/areaofDoctor" element={<AreaOfDoctor/>} />
        <Route path="/route" element={<RouteS/>} />
        <Route path="/ListOfClients" element={< ListOfClients/>} />
        <Route path="/Information" element={< Information/>} />
        <Route path="/loginpatient" element={<LogInPatients />} />
        <Route path="/SignInClient" element={<SignInClient />} />
        
        
        <Route path="/AreaOfPatient" element={<AreaOfPatient/>} /> 
       
      </Routes>
      <Foot></Foot>
      </Router>
    
    </div>
  );
}
export default App;


  





